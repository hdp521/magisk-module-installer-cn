"${0%/*}"/Core/Quick start
