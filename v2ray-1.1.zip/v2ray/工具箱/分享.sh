#节点储存目录
nodeStoreDir='../全局节点'

#清空 [全局节点] 和 [海内节点] 目录(true开启)
clearNodeDir='true'

#节点分享链接(一行一个链接)
nodeLinks='
vmess://eyJhZGQiOiJoazEyLm5pbmdtZW5nc2h1aS50b3AiLCJhaWQiOiIwIiwiaG9zdCI6ImhrLnF1aWNrbmV0LmN5b3UiLCJpZCI6ImFkMTFkYTk4LThlYjctNDQ4Mi04OWEzLTZhMjdmNjYwZWRhMSIsIm5ldCI6IndzIiwicGF0aCI6Ii8iLCJwb3J0IjoiODAiLCJwcyI6IkF66aaZ5rivMTIiLCJzY3kiOiJhdXRvIiwic25pIjoiaGsucXVpY2tuZXQuY3lvdSIsInRscyI6InRscyIsInR5cGUiOiIiLCJ2IjoiMiJ9
'
#mux开关(true开启)
mux='false'

#免流Host, 如果不设置则使用节点自带的
repHost=''

#path, 如果不设置则使用节点自带的
repPath=''


cd "${0%/*}"
sh ../Core/downloadCore.sh "$repHost" 'MLBox' 'Usgae'
echo "节点保存目录为: $PWD/$nodeStoreDir"
echo '所有 节点文件(.ini结尾) 需要复制到 全局节点 或 海内节点 文件夹才可以用'
alias 'MLBox=../Core/MLBox'
mkdir "$nodeStoreDir" 2>/dev/null
[ "$clearNodeDir" = 'true' ] && rm -f "../海内节点/*.ini" "../全局节点/*.ini"
i=1
for v2link in $nodeLinks; do
	v2msg=`MLBox -v2Link="$v2link"`
	eval "$v2msg"
	echo "$ps" | grep -q '/' && ps="${ps//\//\\}"
	filePath="${nodeStoreDir:=$PWD}/${i}_${ps%% *}.ini"
	echo "$v2link" | grep -q '^vless' && protocol='vless' || protocol='vmess'
	echo "protocol=$protocol" >"$filePath"
	echo "mux='$mux'" >>"$filePath"
	echo "$v2msg" | grep -Ev '^host|^sni|^path' >>"$filePath"
	if [ -n "$repHost" ]; then
		host="$repHost"
		sni="$repHost"
	fi
	if [ -n "$repPath" ]; then
		path="$repPath"
	fi
	echo "host='$host'" >>"$filePath"
	echo "sni='$host'" >>"$filePath"
	echo "path='$path'" >>"$filePath"
	echo -E "第$i个节点: ${ps}, 已写入文件: ${i}_${ps%% *}.ini"
	for v in ${v2msg// /_}; do
		unset "${v%=*}"
	done
	i=$((i + 1))
done
